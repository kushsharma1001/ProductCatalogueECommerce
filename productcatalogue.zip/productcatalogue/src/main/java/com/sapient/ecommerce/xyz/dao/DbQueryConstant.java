package com.sapient.ecommerce.xyz.dao;

public class DbQueryConstant {

	private DbQueryConstant() {
	}

	public static final String GET_ALL_PRODUCTS = "select product.id, product.name, product.pricePerPiece, product.discount, product.quantity, "
			+ "color.id as c_id, color.name as c_name, "
			+ "sku.id as sku_id, sku.skuNumber, sku.description as sku_desc, "
			+ "category.id as cat_id, category.name as cat_name, category.description as cat_desc,"
			+ "brand.id as b_id, brand.name as b_name, brand.description as b_desc,"
			+ "seller.id as s_id, seller.name as s_name, seller.email, seller.phone, seller.totalQuantity,"
			+ "size.id as size_id, size.measure, size.unit, size.length, size.breadth, size.height"
			+ " from ((((((product inner join sku ON product.skuId = sku.id) inner join color ON product.colorId = color.id) inner join category ON product.categoryId = category.id) inner join brand ON product.brandId = brand.id)"
			+ " inner join seller ON product.sellerId = seller.id) inner join size ON product.sizeId = size.id)";
	
	public static final String GET_PRODUCTS_BY_SKU = GET_ALL_PRODUCTS + " where sku.id =?";


	public static final String GROUP_BY = " group by ";
	public static final String GROUP_BY_SUFFIX = ", product.id, product.discount";
	public static final String dotID = ".id";
	public static final String GET_SKU_ID_FROM_SKU_NUMBER = "select id from sku where skuNumber=?";
}
