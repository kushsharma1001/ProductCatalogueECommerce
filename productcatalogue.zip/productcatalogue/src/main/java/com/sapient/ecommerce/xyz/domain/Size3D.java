package com.sapient.ecommerce.xyz.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Size3D {

	private long id;
	private Size measure;
	private long length;
	private long breadth;
	private long height;
	private String unit;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Size getMeasure() {
		return measure;
	}

	public void setMeasure(Size measure) {
		this.measure = measure;
	}

	public long getLength() {
		return length;
	}

	public void setLength(long length) {
		this.length = length;
	}

	public long getBreadth() {
		return breadth;
	}

	public void setBreadth(long breadth) {
		this.breadth = breadth;
	}

	public long getHeight() {
		return height;
	}

	public void setHeight(long height) {
		this.height = height;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	@Override
	public String toString() {
		return "Size3D [id=" + id + ", measure=" + measure + ", length=" + length + ", breadth="
				+ breadth + ", height=" + height + ", unit=" + unit + "]";
	}

}
