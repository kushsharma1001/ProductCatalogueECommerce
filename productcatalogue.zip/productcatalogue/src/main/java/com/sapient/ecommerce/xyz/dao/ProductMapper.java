package com.sapient.ecommerce.xyz.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.sapient.ecommerce.xyz.domain.Brand;
import com.sapient.ecommerce.xyz.domain.Category;
import com.sapient.ecommerce.xyz.domain.Color;
import com.sapient.ecommerce.xyz.domain.Product;
import com.sapient.ecommerce.xyz.domain.Seller;
import com.sapient.ecommerce.xyz.domain.Size;
import com.sapient.ecommerce.xyz.domain.Size3D;
import com.sapient.ecommerce.xyz.domain.Sku;

public class ProductMapper implements RowMapper<Product> {

	@Override
	public Product mapRow(ResultSet rs, int rowNum) throws SQLException {
		Product product = new Product();
		
		product.setId(rs.getLong("id"));
		product.setName(rs.getString("name")); 
		product.setDiscount(rs.getFloat("discount"));	
		product.setQuantity(rs.getLong("quantity"));
		product.setPricePerPiece(rs.getDouble("pricePerPiece"));
		
		mapAssociatedProductParams(rs, product);
		return product;
	}

	private void mapAssociatedProductParams(ResultSet rs, Product product) throws SQLException {
		Color color = new Color(); color.setId(rs.getInt("c_id")); color.setName(rs.getString("c_name"));
		product.setColor(color);
		
		Sku sku = new Sku(); sku.setId(rs.getLong("sku_id")); sku.setSkuNumber(rs.getString("skuNumber")); sku.setDescription(rs.getString("sku_desc"));
		product.setSku(sku);
		
		Category category = new Category(); category.setId(rs.getLong("cat_id")); category.setName(rs.getString("cat_name")); category.setDescription(rs.getString("cat_desc"));
		product.setCategory(category);
		
		Brand brand = new Brand(); brand.setId(rs.getLong("b_id")); brand.setName(rs.getString("b_name")); brand.setDescription(rs.getString("b_desc"));
		product.setBrand(brand);
		
		Seller seller = new Seller(); seller.setId(rs.getLong("s_id")); seller.setName(rs.getString("s_name")); seller.setEmail(rs.getString("email")); seller.setPhone(rs.getString("phone")); seller.setTotalQuantity(rs.getLong("totalQuantity"));
		product.setSeller(seller);
		
		Size3D size = new Size3D(); size.setId(rs.getLong("size_id")); mapMeasure(rs, size); size.setUnit(rs.getString("unit")); size.setLength(rs.getLong("length")); size.setBreadth(rs.getLong("breadth")); size.setHeight(rs.getLong("height"));
		product.setSize(size);
	}

	private void mapMeasure(ResultSet rs, Size3D size) throws SQLException {
		
		String measureFromDb = rs.getString("measure");
		if(measureFromDb.equals("L"))
			size.setMeasure(Size.findByValue("Large"));
		else if(measureFromDb.equals("M"))
			size.setMeasure(Size.findByValue("Medium"));
		else if(measureFromDb.equals("S"))
			size.setMeasure(Size.findByValue("Small"));
		else if(measureFromDb.equals("XL"))
			size.setMeasure(Size.findByValue("Extra Large"));
		else if(measureFromDb.equals("XS"))
			size.setMeasure(Size.findByValue("Extra Small"));
		else if(measureFromDb.equals("XXL"))
			size.setMeasure(Size.findByValue("Double XL"));
	}

}
