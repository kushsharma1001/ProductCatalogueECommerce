package com.sapient.ecommerce.xyz.util;

import com.sapient.ecommerce.xyz.domain.Product;
import com.sapient.ecommerce.xyz.exception.InvalidProductException;

public class ProductValidator {

	public static void validatePayload(Product product) {
		checkInvalidPayload(product.getBrand().getName(), "Brand Name");
		checkInvalidPayload(product.getBrand().getId(), "Brand Id");
		checkInvalidPayload(product.getBrand().getDescription(), "Brand Description");
		checkInvalidPayload(product.getSku().getId(), "Sku Id");
		checkInvalidPayload(product.getSku().getSkuNumber(), "Sku Number");
		checkInvalidPayload(product.getSku().getDescription(), "Sku Description");
		checkInvalidPayload(product.getCategory().getId(), "Category Id");
		checkInvalidPayload(product.getCategory().getName(), "Category Name");
		checkInvalidPayload(product.getCategory().getDescription(), "Category Description");
		checkInvalidPayload(product.getId(), "Product Id");
		checkInvalidPayload(product.getName(), "Product Name");
		checkInvalidPayload(product.getPricePerPiece(), "Product Price Per Piece");
		checkInvalidPayload(product.getQuantity(), "Product Quantity");
		checkInvalidPayload(product.getDiscount(), "Product Discount");
		checkInvalidPayload(product.getColor().getName(), "Color Name");
		checkInvalidPayload(product.getColor().getId(), "Color Id");
		//TO DO
	}
	
	public static void checkInvalidPayload(Object obj, String errorCause) {
		if (obj == null || (obj instanceof String && obj.toString().isEmpty())) {
			throw new InvalidProductException(errorCause + " is null or empty.");
		}
	}

}
