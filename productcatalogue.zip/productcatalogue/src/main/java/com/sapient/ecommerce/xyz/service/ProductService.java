package com.sapient.ecommerce.xyz.service;

import java.util.List;

import com.sapient.ecommerce.xyz.domain.Product;
import com.sapient.ecommerce.xyz.domain.Size;

public interface ProductService {
	
	public void addProduct(Product p);
	
	public List<Product> getProductsGroupBy(String type);
	
	public List<Product> getAllProducts();

	public List<Product> getProductsBySku(String skuNumber);

}
