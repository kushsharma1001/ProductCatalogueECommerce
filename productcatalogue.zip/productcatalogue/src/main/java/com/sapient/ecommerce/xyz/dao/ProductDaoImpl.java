package com.sapient.ecommerce.xyz.dao;

import java.util.Collections;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.sapient.ecommerce.xyz.domain.Product;

@Repository
public class ProductDaoImpl implements ProductDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	private static Logger log = LoggerFactory.getLogger(ProductDaoImpl.class);

	@Override
	public List<Product> getProductsGroupBy(String type) {

		String sql = getQueryForGroupBy(type);
		try {
			return (List<Product>) jdbcTemplate.query(sql, new ProductMapper());
		} catch (EmptyResultDataAccessException ee) {
			log.error("No products found in inventory");
			return Collections.emptyList();
		} catch (Exception ee) {
			log.error("Unexpected error occured while retrieving products");
			log.error("Exception is: {}", ee);
			return Collections.emptyList();
		}
	}

	@Override
	public List<Product> getAllProducts() {
		try {
			return (List<Product>) jdbcTemplate.query(DbQueryConstant.GET_ALL_PRODUCTS, new ProductMapper());
		} catch (EmptyResultDataAccessException ee) {
			log.error("No products found in inventory");
			return Collections.emptyList();
		} catch (Exception ee) {
			log.error("Unexpected error occured while retrieving products");
			log.error("Exception is: {}", ee);
			return Collections.emptyList();
		}
	}

	@Override
	public List<Product> getProductsBySku(String skuNumber) {
		try {
			long skuId = jdbcTemplate.queryForObject(DbQueryConstant.GET_SKU_ID_FROM_SKU_NUMBER,
					new Object[] { skuNumber }, Long.class);
			log.debug("skuId retrieved {} for skuNumber {}", skuId, skuNumber);
			return (List<Product>) jdbcTemplate.query(DbQueryConstant.GET_PRODUCTS_BY_SKU, new Object[] { skuId },
					new ProductMapper());
		} catch (EmptyResultDataAccessException ee) {
			log.error("No products found with skuNumber: [{}]", skuNumber);
			return Collections.emptyList();
		} catch (Exception ee) {
			log.error("Unexpected error occured while retrieving products for skuNumber: [{}]", skuNumber);
			log.error("Exception is: {}", ee);
			return Collections.emptyList();
		}
	}

	private String getQueryForGroupBy(String type) {
		StringBuilder tempSql = new StringBuilder();
		tempSql.append(DbQueryConstant.GET_ALL_PRODUCTS);
		tempSql.append(DbQueryConstant.GROUP_BY);
		tempSql.append(type);
		switch (type) {

		case "pricePerPiece":
			break;
		case "size":
			tempSql.append(".length, size.breadth, size.height");
			break;
		default:
			tempSql.append(DbQueryConstant.dotID).toString(); // Brand, Color cases handled here
			break;
		}
		String sql = tempSql.append(DbQueryConstant.GROUP_BY_SUFFIX).toString();
		return sql;
	}
}
