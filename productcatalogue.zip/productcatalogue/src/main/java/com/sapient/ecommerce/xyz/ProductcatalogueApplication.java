package com.sapient.ecommerce.xyz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductcatalogueApplication {//implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(ProductcatalogueApplication.class, args);
	}

}

