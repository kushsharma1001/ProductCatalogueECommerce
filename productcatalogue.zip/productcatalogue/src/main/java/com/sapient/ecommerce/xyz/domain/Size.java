package com.sapient.ecommerce.xyz.domain;

public enum Size {

	L("Large"), XL("Extra Large"), XXL("Double XL"), M("Medium"), S("Small"), XS("Extra Small");

	private String value;

	private Size(String value) {
		this.value = value;
	}

	public static Size findByValue(String byValue) {
		for (Size size : Size.values()) {
			if (size.value.equalsIgnoreCase(byValue))
				return size;
		}
		return null;
	}

}
