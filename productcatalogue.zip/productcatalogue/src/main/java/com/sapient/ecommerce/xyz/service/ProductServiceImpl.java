package com.sapient.ecommerce.xyz.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sapient.ecommerce.xyz.dao.ProductDao;
import com.sapient.ecommerce.xyz.domain.Product;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductDao productDao;

	@Override
	public void addProduct(Product p) {
	}

	@Override
	public List<Product> getProductsGroupBy(String type) {

		return productDao.getProductsGroupBy(type);
	}

	@Override
	public List<Product> getAllProducts() {
		return productDao.getAllProducts();
	}

	@Override
	public List<Product> getProductsBySku(String skuNumber) {
		return productDao.getProductsBySku(skuNumber);
	}

}
