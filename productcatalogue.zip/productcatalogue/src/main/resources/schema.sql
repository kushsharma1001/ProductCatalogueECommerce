create table sku
(
   id bigint PRIMARY KEY,
   skuNumber varchar(50) not null,
   description varchar(255)
);

create table brand
(
   id bigint PRIMARY KEY,
   name varchar(60) not null,
   description varchar(255),
   additionalInfo varchar(255)
);

create table category
(
   id bigint PRIMARY KEY,
   name varchar(50) not null,
   description varchar(255),
   additionalInfo varchar(255)
);

create table color
(
   id integer PRIMARY KEY,
   name varchar(25) not null
);

create table size
(
   id bigint PRIMARY KEY,
   measure varchar(20),
   unit varchar(20),
   length bigint,
   breadth bigint,
   height bigint
);

create table product
(
   id bigint,
   name varchar(250),
   categoryId bigint,
   skuId bigint,
   colorId integer,
   brandId bigint,
   sizeId bigint,
   sellerId bigint,
   discount real not null,
   quantity bigint not null,
   pricePerPiece double precision not null
);

create table seller
(
   id bigint PRIMARY KEY ,
   name varchar(80),
   email varchar(100),
   phone varchar(15),
   totalQuantity bigint
);

