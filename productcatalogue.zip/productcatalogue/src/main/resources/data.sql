-- insert SKU
insert into sku (id, skuNumber) values(1,'10110'); 
insert into sku (id, skuNumber) values(2,'10111');
insert into sku (id, skuNumber) values(3,'10112');
insert into sku (id, skuNumber) values(4,'10113');
insert into sku (id, skuNumber) values(5,'10114');

--insert Brand
insert into brand (id, name, description) values(1,'HRX', 'HRX: stay fit, wear it!');
insert into brand (id, name, description) values(2,'Nike', 'Nike: Just do it!');
insert into brand (id, name, description) values(3,'Puma', 'Puma here');
insert into brand (id, name, description) values(4,'Adidas', 'Adidas: Be the best!');
insert into brand (id, name, description) values(5,'Allen', 'Allen: Its for you!');

-- insert category
insert into category (id, name) values(1,'Upper Clothing');
insert into category (id, name) values(2,'Lower Clothing');
insert into category (id, name) values(3,'Accessories');
insert into category (id, name) values(4,'Electronics');
insert into category (id, name) values(5,'Designer');

--insert color
insert into color (id, name) values(1,'red');
insert into color (id, name) values(2,'blue');
insert into color (id, name) values(3,'yellow');
insert into color (id, name) values(4,'green');
insert into color (id, name) values(5,'gray');

--insert sizes
insert into size(id, measure, unit, length, breadth) values(1,'L', 'cm', 110, 80);
insert into size(id, measure, unit, length, breadth) values(2,'M', 'cm', 100, 70);
insert into size(id, measure, unit, length, breadth) values(3,'S', 'cm', 90, 60);
insert into size(id, measure, unit, length, breadth) values(4,'XS', 'cm', 50, 40);
insert into size(id, measure, unit, length, breadth) values(5,'XL', 'cm', 140, 110);
insert into size(id, measure, unit, length, breadth) values(6,'L', 'cm', 50, 30);
insert into size(id, measure, unit, length, breadth) values(7,'M', 'cm', 200, 15);

--insert seller
insert into seller(id, name, email, phone, totalQuantity) values(1,'Seller1', 'Seller1@dummy.com', 'Seller1Phone', 30);
insert into seller(id, name, email, phone, totalQuantity) values(2,'Seller2', 'Seller2@dummy.com', 'Seller2Phone', 200);
insert into seller(id, name, email, phone, totalQuantity) values(3,'Seller3', 'Seller3@dummy.com', 'Seller3Phone', 300);
insert into seller(id, name, email, phone, totalQuantity) values(4,'Seller4', 'Seller4@dummy.com', 'Seller4Phone', 400);
insert into seller(id, name, email, phone, totalQuantity) values(5,'Seller5', 'Seller5@dummy.com', 'Seller5Phone', 500);
insert into seller(id, name, email, phone, totalQuantity) values(6,'Seller6', 'Seller6@dummy.com', 'Seller6Phone', 15);

--insert product
insert into product (id, name, categoryId, skuId, colorId, brandId, sizeId, sellerId, discount, quantity, pricePerPiece) values(4,'Gloves',4,4,4,4,4,4,25,400,800);
insert into product (id, name, categoryId, skuId, colorId, brandId, sizeId, sellerId, discount, quantity, pricePerPiece) values(5,'Tie',5,5,5,5,5,5,30,500,900);
insert into product (id, name, categoryId, skuId, colorId, brandId, sizeId, sellerId, discount, quantity, pricePerPiece) values(1,'TShirt',1,1,1,3,1,1,10,10,500);
insert into product (id, name, categoryId, skuId, colorId, brandId, sizeId, sellerId, discount, quantity, pricePerPiece) values(2,'Jeans',2,2,2,2,2,2,15,200,600);
insert into product (id, name, categoryId, skuId, colorId, brandId, sizeId, sellerId, discount, quantity, pricePerPiece) values(3,'Socks',3,3,3,3,3,3,20,300,700);
insert into product (id, name, categoryId, skuId, colorId, brandId, sizeId, sellerId, discount, quantity, pricePerPiece) values(1,'Jeans',1,1,2,1,1,1,11,5,500);
insert into product (id, name, categoryId, skuId, colorId, brandId, sizeId, sellerId, discount, quantity, pricePerPiece) values(1,'Jeans',1,1,1,1,1,6,12,15,1500);
