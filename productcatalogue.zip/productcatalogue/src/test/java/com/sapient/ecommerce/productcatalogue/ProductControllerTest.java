package com.sapient.ecommerce.productcatalogue;

import java.util.Collections;
import java.util.List;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import com.sapient.ecommerce.xyz.controller.ProductController;
import com.sapient.ecommerce.xyz.domain.Product;
import com.sapient.ecommerce.xyz.service.ProductService;

//@RunWith(PowerMockRunner.class)
//@PrepareForTest({ static classes })
public class ProductControllerTest {

	@InjectMocks
	private ProductController productController;
	private List<Product> expectedProductList;

	@Mock
	private ProductService productService;

	@Before
	public void setup() {
		//PowerMockito.mockStatic(SystemVariables.class);
		MockitoAnnotations.initMocks(this);
		expectedProductList = ProductControllerTestData.generateDefaultProductList();
		Mockito.when(productService.getAllProducts()).thenReturn(expectedProductList);
	}

	@Test
	public void getAllProductsTest() {
		//Products available in Inventory
		ResponseEntity<List<Product>> actualResult = productController.getAllProducts();
		Assert.assertEquals(expectedProductList.size(), actualResult.getBody().size());
		Assert.assertEquals(HttpStatus.OK, actualResult.getStatusCode());
		
		//No Product in Inventory
		Mockito.when(productService.getAllProducts()).thenReturn(Collections.emptyList());
		actualResult = productController.getAllProducts();
		Assert.assertEquals(Collections.EMPTY_LIST.size(), actualResult.getBody().size());
		Assert.assertEquals(HttpStatus.OK, actualResult.getStatusCode());
	}

}
