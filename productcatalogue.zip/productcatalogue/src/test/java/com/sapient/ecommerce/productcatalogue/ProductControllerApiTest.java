package com.sapient.ecommerce.productcatalogue;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sapient.ecommerce.xyz.controller.ProductController;
import com.sapient.ecommerce.xyz.domain.Product;
import com.sapient.ecommerce.xyz.service.ProductService;

@AutoConfigureMockMvc
@ContextConfiguration(classes = {ProductController.class})
@WebMvcTest
public class ProductControllerApiTest {

	    @Autowired
	    private MockMvc mockMvc;

	    @MockBean
	    private ProductService productService;
	    
	    private static final String baseUrl = "/product";
	    private List<Product> expectedProductList;
	    
	    @BeforeEach
	    public void setup() throws Exception {
			expectedProductList = ProductControllerTestData.generateDefaultProductList();
			Mockito.when(productService.getAllProducts()).thenReturn(expectedProductList);
	    }
	    
	    @Test
	    public void getAllProductsTest_Success() throws Exception {
	        //getAllProducts from inventory
	        this.mockMvc
	                .perform(get(baseUrl + "/v1/all")).andExpect(status().isOk()).andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(content().json(new ObjectMapper().writeValueAsString(expectedProductList)));
	    }
	    
	    @Test
	    public void getAllProductsTest_NoProductAvailable() throws Exception {
	        //getAllProducts from inventory
	    	expectedProductList = Collections.emptyList();
	    	Mockito.when(productService.getAllProducts()).thenReturn(expectedProductList);
	    	this.mockMvc
	                .perform(get(baseUrl + "/v1/all")).andExpect(status().isOk()).andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE)).andExpect(content().json(new ObjectMapper().writeValueAsString(expectedProductList)));
	    }
}
