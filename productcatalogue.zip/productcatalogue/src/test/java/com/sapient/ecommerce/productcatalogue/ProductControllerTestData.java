package com.sapient.ecommerce.productcatalogue;

import java.util.ArrayList;
import java.util.List;
import com.sapient.ecommerce.xyz.domain.Brand;
import com.sapient.ecommerce.xyz.domain.Category;
import com.sapient.ecommerce.xyz.domain.Color;
import com.sapient.ecommerce.xyz.domain.Product;
import com.sapient.ecommerce.xyz.domain.Seller;
import com.sapient.ecommerce.xyz.domain.Size;
import com.sapient.ecommerce.xyz.domain.Size3D;
import com.sapient.ecommerce.xyz.domain.Sku;

public class ProductControllerTestData {
	
	public static List<Product> generateDefaultProductList() {
		List<Product> dummyList = new ArrayList();
		Product product = new Product();
		product.setId(1l);
		product.setName("TShirt");
		product.setDiscount(10.0f);
		product.setQuantity(100);
		product.setPricePerPiece(599d);

		mapAssociatedProductParams(product);
		dummyList.add(product);
		return dummyList;
	}

	public static void mapAssociatedProductParams(Product product) {
		Color color = new Color();
		color.setId(1);
		color.setName("Red");
		product.setColor(color);

		Sku sku = new Sku();
		sku.setId(1l);
		sku.setSkuNumber("SKU-LTP-10110");
		sku.setDescription("Dummy description for SKU");
		product.setSku(sku);

		Category category = new Category();
		category.setId(1l);
		category.setName("Clothings");
		category.setDescription("Dummy description for Category");
		product.setCategory(category);

		Brand brand = new Brand();
		brand.setId(1l);
		brand.setName("HRX");
		brand.setDescription("Dummy description for Brand");
		product.setBrand(brand);

		Seller seller = new Seller();
		seller.setId(1l);
		seller.setName("Seller Sharma 1");
		seller.setEmail("seller.sharma1@gmail.com");
		seller.setPhone("9928056780");
		seller.setTotalQuantity(100l);
		product.setSeller(seller);

		Size3D size = new Size3D();
		size.setId(1l);
		size.setUnit("cm");
		size.setLength(150l);
		size.setBreadth(85l);
		size.setHeight(0l);
		size.setMeasure(Size.L);
		product.setSize(size);
	}
}